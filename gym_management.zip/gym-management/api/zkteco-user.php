<?php
/**
 * ZKTeco User Management API
 * FIXED VERSION - No duplicate cases, proper error handling
 */

require_once dirname(__DIR__) . '/config/config.php';

use Gym\Core\Database;
use Gym\Core\ZKTeco;

header('Content-Type: application/json');

try {
    $action = $_POST['action'] ?? '';
    $memberId = intval($_POST['member_id'] ?? 0);
    $biometricId = intval($_POST['biometric_id'] ?? 0);

    error_log("ZKTeco API called: action=$action, memberId=$memberId, biometricId=$biometricId");

    if (empty($biometricId)) {
        echo json_encode([
            'success' => false,
            'message' => 'Biometric ID is required'
        ]);
        exit;
    }

    // Get device
    $device = Database::fetchOne(
        "SELECT * FROM zkteco_devices WHERE is_default = 1 LIMIT 1"
    );
    
    if (!$device) {
        echo json_encode([
            'success' => false,
            'message' => 'No default device configured'
        ]);
        exit;
    }

    error_log("ZKTeco API: Using device {$device['device_name']} at {$device['device_ip']}");

    // Connect to device
    $zk = new ZKTeco($device['device_ip'], (int)$device['port']);
    
    if (!$zk->connect()) {
        echo json_encode([
            'success' => false, 
            'message' => 'Failed to connect to device at ' . $device['device_ip'] . ':' . $device['port']
        ]);
        exit;
    }

    $result = ['success' => false, 'message' => 'Unknown action'];

    // ✅ FIXED: Single switch with proper cases (no duplicates)
    switch ($action) {
        
        case 'add':
            // Get member info
            $member = Database::fetchOne(
                "SELECT first_name, last_name FROM members WHERE id = ?",
                [$memberId]
            );

            $fullName = '';
            if ($member) {
                $fullName = trim(
                    ($member['first_name'] ?? '') . ' ' . 
                    ($member['last_name'] ?? '')
                );
            }

            if (empty($fullName)) {
                $fullName = "User $biometricId";
            }

            error_log("ZKTeco API: Adding user - biometric=$biometricId, name='$fullName'");

            // Call device method
            if ($zk->addUser($biometricId, $fullName, '', 0, (string)$biometricId)) {
                // Update database
                if ($memberId > 0) {
                    Database::execute(
                        "UPDATE members SET biometric_id = ? WHERE id = ?",
                        [$biometricId, $memberId]
                    );
                }
                
                $result = [
                    'success' => true,
                    'message' => "User '$fullName' added to device successfully"
                ];
            } else {
                $result = [
                    'success' => false,
                    'message' => 'Device rejected user creation (check logs for details)'
                ];
            }
            break;

        case 'remove':
            error_log("ZKTeco API: Removing user - biometric=$biometricId");
            
            if ($zk->removeUser($biometricId)) {
                // Clear biometric_id from database
                if ($memberId > 0) {
                    Database::execute(
                        "UPDATE members SET biometric_id = NULL WHERE id = ?",
                        [$memberId]
                    );
                }
                
                $result = [
                    'success' => true,
                    'message' => 'User removed from device'
                ];
            } else {
                $result = [
                    'success' => false,
                    'message' => 'Failed to remove user from device'
                ];
            }
            break;

        case 'enable':
            error_log("ZKTeco API: Enabling user - biometric=$biometricId");
            
            if ($zk->enableUser($biometricId)) {
                $result = [
                    'success' => true,
                    'message' => 'User enabled on device'
                ];
            } else {
                $result = [
                    'success' => false,
                    'message' => 'Failed to enable user'
                ];
            }
            break;

        case 'disable':
            error_log("ZKTeco API: Disabling user - biometric=$biometricId");
            
            if ($zk->disableUser($biometricId)) {
                $result = [
                    'success' => true,
                    'message' => 'User disabled on device'
                ];
            } else {
                $result = [
                    'success' => false,
                    'message' => 'Failed to disable user'
                ];
            }
            break;
            
        default:
            error_log("ZKTeco API: Invalid action '$action'");
            $result = [
                'success' => false,
                'message' => 'Invalid action: ' . htmlspecialchars($action)
            ];
    }

    $zk->disconnect();
    error_log("ZKTeco API: Result - " . json_encode($result));
    echo json_encode($result);

} catch (\Exception $e) {
    error_log('ZKTeco API Error: ' . $e->getMessage());
    error_log('Stack trace: ' . $e->getTraceAsString());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Server error: ' . $e->getMessage()
    ]);
}
?>