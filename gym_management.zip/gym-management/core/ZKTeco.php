<?php
/**
 * ZKTeco Wrapper - bridges the working ZKLib library with the Gym application
 * FIXED VERSION
 */

namespace Gym\Core;

require_once BASE_PATH . '/zklib/ZKLib.php';

class ZKTeco
{
    private $ip;
    private $port;
    private $zk = null;
    private $connected = false;

    public function __construct($ip, $port = 4370)
    {
        $this->ip = $ip;
        $this->port = $port;
    }

    /**
     * Connect to device
     */
    public function connect()
    {
        try {
            $this->zk = new \ZKLib($this->ip, $this->port);
            $this->connected = $this->zk->connect();
            
            if ($this->connected && method_exists($this->zk, 'disableDevice')) {
                $this->zk->disableDevice();
            }
            
            return $this->connected;
        } catch (\Exception $e) {
            error_log('ZKTeco connect error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Disconnect cleanly
     */
    public function disconnect()
    {
        if ($this->zk) {
            if ($this->connected && method_exists($this->zk, 'enableDevice')) {
                $this->zk->enableDevice();
            }
            if (method_exists($this->zk, 'disconnect')) {
                $this->zk->disconnect();
            }
        }
        $this->connected = false;
        $this->zk = null;
    }

    /**
     * Static test helper
     */
    public static function testConnection($ip, $port = 4370)
    {
        $zk = new self($ip, $port);
        if ($zk->connect()) {
            $zk->disconnect();
            return ['success' => true, 'message' => 'Connection successful'];
        }
        return ['success' => false, 'message' => 'Could not connect to ' . $ip . ':' . $port];
    }

    /**
     * Restart device
     */
    public function restart()
    {
        if (!$this->connected || !$this->zk) {
            return ['success' => false, 'message' => 'Not connected to device'];
        }
        
        if (method_exists($this->zk, 'restart')) {
            $this->zk->restart();
            return ['success' => true, 'message' => 'Device restart command sent successfully'];
        }
        
        return ['success' => false, 'message' => 'Restart command not available'];
    }

    /**
     * Add single user to device
     * 
     * ✅ FIXED: Proper error handling and method detection
     */
    public function addUser($userId, $name, $password = '', $role = 0, $cardno = '')
{
    if (!$this->connected || !$this->zk) {
        error_log("ZKTeco: Not connected to device");
        return false;
    }

    $userId = (int)$userId;
    $name = trim(substr($name, 0, 24));

    if (empty($name)) {
        $name = "User $userId";
    }

    if (empty($cardno)) {
        $cardno = (string)$userId;
    }

    error_log("ZKTeco: Adding user - ID=$userId Name=$name Card=$cardno");

    try {

        if (!method_exists($this->zk, 'setUser')) {
            error_log("ZKTeco: setUser not supported by library");
            return false;
        }

        $result = $this->zk->setUser(
            $userId,
            (string)$userId,
            $name,
            $password,
            (int)$role,
            $cardno
        );

        error_log("ZKTeco setUser result: " . var_export($result, true));

        return ($result !== false && $result !== null);

    } catch (\Exception $e) {
        error_log("ZKTeco addUser exception: " . $e->getMessage());
        return false;
    }
}

    /**
     * Remove user from device
     * 
     * ✅ FIXED: Proper implementation
     */
    public function removeUser($userId)
    {
        if (!$this->connected || !$this->zk) {
            error_log("ZKTeco: Not connected to device");
            return false;
        }

        $userId = (int)$userId;
        error_log("ZKTeco: Removing user ID=$userId");

        try {
            // Try different method names
            if (method_exists($this->zk, 'removeUser')) {
                $result = $this->zk->removeUser($userId);
                error_log("ZKTeco removeUser result: " . var_export($result, true));
                return $result !== false;
            }
            
            if (method_exists($this->zk, 'deleteUser')) {
                $result = $this->zk->deleteUser($userId);
                error_log("ZKTeco deleteUser result: " . var_export($result, true));
                return $result !== false;
            }
            
            error_log("ZKTeco: No remove user method found");
            return false;
            
        } catch (\Exception $e) {
            error_log("ZKTeco: Exception removing user - " . $e->getMessage());
            return false;
        }
    }

    /**
     * Enable user on device
     * 
     * ✅ FIXED: Actual implementation
     */
    public function enableUser($userId)
    {
        if (!$this->connected || !$this->zk) {
            error_log("ZKTeco: Not connected to device");
            return false;
        }

        $userId = (int)$userId;
        error_log("ZKTeco: Enabling user ID=$userId");

        try {
            if (method_exists($this->zk, 'enableUser')) {
                $result = $this->zk->enableUser($userId);
                error_log("ZKTeco enableUser result: " . var_export($result, true));
                return $result !== false;
            }
            
            // Some devices don't have this - just return true
            return true;
            
        } catch (\Exception $e) {
            error_log("ZKTeco: Exception enabling user - " . $e->getMessage());
            return false;
        }
    }

    /**
     * Disable user on device
     * 
     * ✅ FIXED: Actual implementation
     */
    public function disableUser($userId)
    {
        if (!$this->connected || !$this->zk) {
            error_log("ZKTeco: Not connected to device");
            return false;
        }

        $userId = (int)$userId;
        error_log("ZKTeco: Disabling user ID=$userId");

        try {
            if (method_exists($this->zk, 'disableUser')) {
                $result = $this->zk->disableUser($userId);
                error_log("ZKTeco disableUser result: " . var_export($result, true));
                return $result !== false;
            }
            
            // Some devices don't have this - just return true
            return true;
            
        } catch (\Exception $e) {
            error_log("ZKTeco: Exception disabling user - " . $e->getMessage());
            return false;
        }
    }

    /**
     * Sync users from database to device
     * 
     * ✅ FIXED: Actually loops and adds users
     */
    public function syncUsersFromDb($members)
    {
        if (!$this->connected || !$this->zk) {
            return [
                'success' => false,
                'message' => 'Not connected to device',
                'total' => 0,
                'successful' => 0,
                'failed' => 0
            ];
        }

        if (empty($members)) {
            return [
                'success' => true,
                'message' => 'No members to sync',
                'total' => 0,
                'successful' => 0,
                'failed' => 0
            ];
        }

        error_log("ZKTeco: Syncing " . count($members) . " members to device");

        $successful = 0;
        $failed = 0;

        foreach ($members as $member) {
            if (empty($member['biometric_id'])) {
                error_log("ZKTeco: Skipping member {$member['id']} - no biometric_id");
                $failed++;
                continue;
            }

            $userId = (int)$member['biometric_id'];
            $name = trim(
                ($member['first_name'] ?? '') . ' ' . 
                ($member['last_name'] ?? '')
            );
            
            if (empty($name)) {
                $name = "Member $userId";
            }

            error_log("ZKTeco: Syncing member {$member['id']} as $userId: $name");

            if ($this->addUser($userId, $name, '', 0, (string)$userId)) {
                $successful++;
            } else {
                $failed++;
            }

            // Small delay between requests to avoid overwhelming device
            usleep(100000); // 100ms
        }

        $message = "Synced $successful members successfully";
        if ($failed > 0) {
            $message .= ", $failed failed";
        }

        return [
            'success' => $failed == 0,
            'message' => $message,
            'total' => count($members),
            'successful' => $successful,
            'failed' => $failed
        ];
    }

    /**
     * Get attendance records from device
     */
    public function getAttendance()
    {
        if (!$this->connected || !$this->zk) {
            return [];
        }
        
        try {
            if (!method_exists($this->zk, 'getAttendance')) {
                error_log("ZKTeco: getAttendance method not available");
                return [];
            }
            
            $data = $this->zk->getAttendance();
            
            if (!is_array($data) || empty($data)) {
                return [];
            }
            
            // Reverse to chronological order (oldest first)
            $data = array_reverse($data, true);
            
            $normalized = [];
            foreach ($data as $item) {
                $normalized[] = [
                    'uid' => $item['uid'] ?? ($item['UID'] ?? 0),
                    'id' => $item['id'] ?? ($item['userid'] ?? ($item['ID'] ?? '')),
                    'userid' => $item['userid'] ?? ($item['id'] ?? ''),
                    'name' => $item['name'] ?? '',
                    'timestamp' => $item['timestamp'] ?? ($item['punch_time'] ?? date('Y-m-d H:i:s')),
                    'state' => $item['state'] ?? ($item['status'] ?? 0),
                    'type' => $item['type'] ?? 0,
                ];
            }
            
            return $normalized;
            
        } catch (\Exception $e) {
            error_log("ZKTeco: Exception getting attendance - " . $e->getMessage());
            return [];
        }
    }

    /**
     * Clear attendance log
     */
    public function clearAttendance()
    {
        if (!$this->connected || !$this->zk) {
            return false;
        }
        
        try {
            if (method_exists($this->zk, 'clearAttendance')) {
                $this->zk->clearAttendance();
                return true;
            }
            
            return false;
            
        } catch (\Exception $e) {
            error_log("ZKTeco: Exception clearing attendance - " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get device info
     */
    public function getDeviceInfo()
    {
        if (!$this->connected || !$this->zk) {
            return [];
        }
        
        try {
            $info = [];
            if (method_exists($this->zk, 'version')) {
                $info['version'] = $this->zk->version();
            }
            if (method_exists($this->zk, 'serialNumber')) {
                $info['serial'] = $this->zk->serialNumber();
            }
            if (method_exists($this->zk, 'deviceName')) {
                $info['name'] = $this->zk->deviceName();
            }
            
            return $info;
            
        } catch (\Exception $e) {
            error_log("ZKTeco: Exception getting device info - " . $e->getMessage());
            return [];
        }
    }
}
?>